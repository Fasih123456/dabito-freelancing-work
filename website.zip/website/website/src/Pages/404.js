function ErrorPage() {
  return <div>This page was not found</div>;
}

export default ErrorPage;
